/*****************************************************************
|
|   Platinum - AV Media Renderer Device
|
| Copyright (c) 2004-2010, Plutinosoft, LLC.
| All rights reserved.
| http://www.plutinosoft.com
|
| This program is free software; you can redistribute it and/or
| modify it under the terms of the GNU General Public License
| as published by the Free Software Foundation; either version 2
| of the License, or (at your option) any later version.
|
| OEMs, ISVs, VARs and other distributors that combine and 
| distribute commercially licensed software with Platinum software
| and do not wish to distribute the source code for the commercially
| licensed software under version 2, or (at your option) any later
| version, of the GNU General Public License (the "GPL") must enter
| into a commercial license agreement with Plutinosoft, LLC.
| licensing@plutinosoft.com
| 
| This program is distributed in the hope that it will be useful,
| but WITHOUT ANY WARRANTY; without even the implied warranty of
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
| GNU General Public License for more details.
|
| You should have received a copy of the GNU General Public License
| along with this program; see the file LICENSE.txt. If not, write to
| the Free Software Foundation, Inc., 
| 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
| http://www.gnu.org/licenses/gpl-2.0.html
|
****************************************************************/

/*----------------------------------------------------------------------
|   includes
+---------------------------------------------------------------------*/
#include "Neptune.h"
#include "PltMediaRenderer.h"
#include "PltService.h"

#include <stdlib.h>
#include <unistd.h>

NPT_SET_LOCAL_LOGGER("platinum.media.renderer")

/*----------------------------------------------------------------------
|   external references
+---------------------------------------------------------------------*/
extern NPT_UInt8 RDR_ConnectionManagerSCPD[];
extern NPT_UInt8 RDR_AVTransportSCPD[];
extern NPT_UInt8 RDR_RenderingControlSCPD[];

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::PLT_MediaRenderer
+---------------------------------------------------------------------*/
PLT_MediaRenderer::PLT_MediaRenderer(const char*  friendly_name, 
                                     bool         show_ip     /* = false */, 
                                     const char*  uuid        /* = NULL */, 
                                     unsigned int port        /* = 0 */,
                                     bool         port_rebind /* = false */) :	
    PLT_DeviceHost("/", 
                   uuid, 
                   "urn:schemas-upnp-org:device:MediaRenderer:1", 
                   friendly_name, 
                   show_ip, 
                   port, 
                   port_rebind),
    m_Delegate(NULL),
	last_duration(-1), last_position(-1), seek_target(-1)
{
    m_ModelDescription = "Jlt AV Media Renderer Device";
    m_ModelURL         = "";
    m_ModelNumber      = "1.0";
    m_ModelName        = "jlt-dmr";
    m_Manufacturer     = "JLT";
    m_ManufacturerURL  = "gaoqiang1211@gmail.com";
    m_DlnaDoc          = "DMR-1.50";
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::~PLT_MediaRenderer
+---------------------------------------------------------------------*/
PLT_MediaRenderer::~PLT_MediaRenderer()
{
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::SetupServices
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::SetupServices()
{
    NPT_Reference<PLT_Service> service;

    {
        /* AVTransport */
        service = new PLT_Service(
            this,
            "urn:schemas-upnp-org:service:AVTransport:1", 
            "urn:upnp-org:serviceId:AVTransport",
            "AVTransport",
            "urn:schemas-upnp-org:metadata-1-0/AVT/");
        NPT_CHECK_FATAL(service->SetSCPDXML((const char*) RDR_AVTransportSCPD));
        NPT_CHECK_FATAL(AddService(service.AsPointer()));

        service->SetStateVariableRate("LastChange", NPT_TimeInterval(0.2f));
        service->SetStateVariable("A_ARG_TYPE_InstanceID", "0"); 

        // GetCurrentTransportActions
        service->SetStateVariable("CurrentTransportActions", "PLAY");

        // GetDeviceCapabilities
        service->SetStateVariable("PossiblePlaybackStorageMedia", "NONE,NETWORK,HDD,CD-DA,UNKNOWN");
        service->SetStateVariable("PossibleRecordStorageMedia", "NOT_IMPLEMENTED");
        service->SetStateVariable("PossibleRecordQualityModes", "NOT_IMPLEMENTED");

        // GetMediaInfo
        service->SetStateVariable("NumberOfTracks", "0");
        service->SetStateVariable("CurrentMediaDuration", "00:00:00");
        service->SetStateVariable("AVTransportURI", "");
        service->SetStateVariable("AVTransportURIMetadata", "");
        service->SetStateVariable("NextAVTransportURI", "NOT_IMPLEMENTED");
        service->SetStateVariable("NextAVTransportURIMetadata", "NOT_IMPLEMENTED");
        service->SetStateVariable("PlaybackStorageMedium", "NONE");
        service->SetStateVariable("RecordStorageMedium", "NOT_IMPLEMENTED");
		service->SetStateVariable("RecordMediumWriteStatus", "NOT_IMPLEMENTED");

        // GetPositionInfo
        service->SetStateVariable("CurrentTrack", "0");
        service->SetStateVariable("CurrentTrackDuration", "00:00:00");
        service->SetStateVariable("CurrentTrackMetadata", "");
        service->SetStateVariable("CurrentTrackURI", "");
        service->SetStateVariable("RelativeTimePosition", "00:00:00"); 
        service->SetStateVariable("AbsoluteTimePosition", "00:00:00");
        service->SetStateVariable("RelativeCounterPosition", "2147483647"); // means NOT_IMPLEMENTED
        service->SetStateVariable("AbsoluteCounterPosition", "2147483647"); // means NOT_IMPLEMENTED

        // disable indirect eventing for certain state variables
        PLT_StateVariable* var;
        var = service->FindStateVariable("RelativeTimePosition");
        if (var) var->DisableIndirectEventing();
        var = service->FindStateVariable("AbsoluteTimePosition");
        if (var) var->DisableIndirectEventing();
        var = service->FindStateVariable("RelativeCounterPosition");
        if (var) var->DisableIndirectEventing();
        var = service->FindStateVariable("AbsoluteCounterPosition");
        if (var) var->DisableIndirectEventing();

        // GetTransportInfo
        service->SetStateVariable("TransportState", "NO_MEDIA_PRESENT");
        service->SetStateVariable("TransportStatus", "OK");
        service->SetStateVariable("TransportPlaySpeed", "1");

        // GetTransportSettings
        service->SetStateVariable("CurrentPlayMode", "NORMAL");
        service->SetStateVariable("CurrentRecordQualityMode", "NOT_IMPLEMENTED");
        
        service.Detach();
        service = NULL;
    }

    {
        /* ConnectionManager */
        service = new PLT_Service(
            this,
            "urn:schemas-upnp-org:service:ConnectionManager:1", 
            "urn:upnp-org:serviceId:ConnectionManager",
            "ConnectionManager");
        NPT_CHECK_FATAL(service->SetSCPDXML((const char*) RDR_ConnectionManagerSCPD));
        NPT_CHECK_FATAL(AddService(service.AsPointer()));

        service->SetStateVariable("CurrentConnectionIDs", "0");

        // put all supported mime types here instead
        service->SetStateVariable("SinkProtocolInfo"
		,"http-get:*:*:*"
		",http-get:*:audio/*:*"
		",http-get:*:audio/L8:*"
		",http-get:*:audio/L16:*"
		",http-get:*:audio/wav:*"
		",http-get:*:audio/x-wav:*"
		",http-get:*:audio/x-ms-wma:*"
		",http-get:*:audio/mpeg:*"
		",http-get:*:audio/x-mpeg:*"
		",http-get:*:audio/x-m4a:*"
		",http-get:*:audio/m4a:*"
		",http-get:*:audio/mp4:*"
		",http-get:*:audio/aac:*"
		",http-get:*:audio/ape:*"
		",http-get:*:audio/flac:*"
		",http-get:*:audio/x-flac:*"
		",http-get:*:audio/ogg:*"
		);
        service->SetStateVariable("SourceProtocolInfo", "");
        
        service.Detach();
        service = NULL;
    }

    {
        /* RenderingControl */
        service = new PLT_Service(
            this,
            "urn:schemas-upnp-org:service:RenderingControl:1", 
            "urn:upnp-org:serviceId:RenderingControl",
            "RenderingControl",
            "urn:schemas-upnp-org:metadata-1-0/RCS/");
        NPT_CHECK_FATAL(service->SetSCPDXML((const char*) RDR_RenderingControlSCPD));
        NPT_CHECK_FATAL(AddService(service.AsPointer()));

        service->SetStateVariableRate("LastChange", NPT_TimeInterval(0.2f));

        service->SetStateVariable("Mute", "0");
        service->SetStateVariableExtraAttribute("Mute", "Channel", "Master");
        system("amixer cset numid=5 87");
        service->SetStateVariable("Volume", "50");
        service->SetStateVariableExtraAttribute("Volume", "Channel", "Master");
        service->SetStateVariable("VolumeDB", "0");
        service->SetStateVariableExtraAttribute("VolumeDB", "Channel", "Master");

        service->SetStateVariable("PresetNameList", "FactoryDefaults");
        
        service.Detach();
        service = NULL;
    }

    return NPT_SUCCESS;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnAction
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnAction(PLT_ActionReference&          action, 
                            const PLT_HttpRequestContext& context)
{
    NPT_COMPILER_UNUSED(context);

    /* parse the action name */
    NPT_String name = action->GetActionDesc().GetName();

	//printf("%s: %s.\n", __FUNCTION__, name.GetChars());

    // since all actions take an instance ID and we only support 1 instance
    // verify that the Instance ID is 0 and return an error here now if not
    NPT_String serviceType = action->GetActionDesc().GetService()->GetServiceType();
    if (serviceType.Compare("urn:schemas-upnp-org:service:AVTransport:1", true) == 0) {
        if (NPT_FAILED(action->VerifyArgumentValue("InstanceID", "0"))) {
            action->SetError(718, "Not valid InstanceID");
            return NPT_FAILURE;
        }
    }
	serviceType = action->GetActionDesc().GetService()->GetServiceType();
	if (serviceType.Compare("urn:schemas-upnp-org:service:RenderingControl:1", true) == 0) {
		if (NPT_FAILED(action->VerifyArgumentValue("InstanceID", "0"))) {
			action->SetError(702, "Not valid InstanceID");
			return NPT_FAILURE;
		}
	}

	/* Is it a ConnectionManager Service Action ? */
	if (name.Compare("GetCurrentConnectionInfo", true) == 0) {
		return OnGetCurrentConnectionInfo(action);
	}  

	/* Is it a AVTransport Service Action ? */
    if (name.Compare("Next", true) == 0) {
        return OnNext(action);
    }
    if (name.Compare("Pause", true) == 0) {
        return OnPause(action);
    }
    if (name.Compare("Play", true) == 0) {
        return OnPlay(action);
    }
    if (name.Compare("Previous", true) == 0) {
        return OnPrevious(action);
    }
    if (name.Compare("Seek", true) == 0) {
        return OnSeek(action);
    }
    if (name.Compare("Stop", true) == 0) {
        return OnStop(action);
    }
    if (name.Compare("SetAVTransportURI", true) == 0) {
        return OnSetAVTransportURI(action);
    }
    if (name.Compare("SetPlayMode", true) == 0) {
        return OnSetPlayMode(action);
    }

    /* Is it a RendererControl Service Action ? */
    if (name.Compare("SetVolume", true) == 0) {
          return OnSetVolume(action);
    }
	if (name.Compare("SetVolumeDB", true) == 0) {
		return OnSetVolumeDB(action);
    }
	if (name.Compare("GetVolumeDBRange", true) == 0) {
		return OnGetVolumeDBRange(action);

	}
    if (name.Compare("SetMute", true) == 0) {
          return OnSetMute(action);
    }

    // other actions rely on state variables
    NPT_CHECK_LABEL_WARNING(action->SetArgumentsOutFromStateVariable(), failure);
    return NPT_SUCCESS;

failure:
    action->SetError(401,"No Such Action.");
    return NPT_FAILURE;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnGetCurrentConnectionInfo
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnGetCurrentConnectionInfo(PLT_ActionReference& action)
{
    if (m_Delegate) {
        return m_Delegate->OnGetCurrentConnectionInfo(action);
    }
    
    if (NPT_FAILED(action->VerifyArgumentValue("ConnectionID", "0"))) {
        action->SetError(706,"No Such Connection.");
        return NPT_FAILURE;
    }

    if (NPT_FAILED(action->SetArgumentValue("RcsID", "0"))){
        return NPT_FAILURE;
    }
    if (NPT_FAILED(action->SetArgumentValue("AVTransportID", "0"))) {
        return NPT_FAILURE;
    }
    if (NPT_FAILED(action->SetArgumentOutFromStateVariable("ProtocolInfo"))) {
        return NPT_FAILURE;
    }
    if (NPT_FAILED(action->SetArgumentValue("PeerConnectionManager", "/"))) {
        return NPT_FAILURE;
    }
    if (NPT_FAILED(action->SetArgumentValue("PeerConnectionID", "-1"))) {
        return NPT_FAILURE;
    }
    if (NPT_FAILED(action->SetArgumentValue("Direction", "Input"))) {
        return NPT_FAILURE;
    }
    if (NPT_FAILED(action->SetArgumentValue("Status", "Unknown"))) {
        return NPT_FAILURE;
    }

    return NPT_SUCCESS;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnNext
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnNext(PLT_ActionReference& action)
{
    if (m_Delegate) {
        return m_Delegate->OnNext(action);
    }
    return NPT_ERROR_NOT_IMPLEMENTED;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnPause
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnPause(PLT_ActionReference& action)
{
	NPT_AutoLock lock(m_state);

    if (m_Delegate) {
        return m_Delegate->OnPause(action);
    }

    PLT_Service *avt;
	FindServiceByType("urn:schemas-upnp-org:service:AVTransport:1", avt);
	NPT_String pre_state;
    avt->GetStateVariableValue("TransportState", pre_state);

	if(!pre_state.Compare("PAUSED_PLAYBACK"))
	{
		printf("%s: Warn: no change.\n", __FUNCTION__);
		return NPT_SUCCESS;
	}
	else if(!pre_state.Compare("PLAYING") || !pre_state.Compare("TRANSITIONING"))
	{
		// play->pause
		printf("%s: play->pause.\n", __FUNCTION__);
		// pause
		system("echo \"pause\" > /tmp/mplayer-infifo");
	}
	else
	{
		printf("%s: Error: %s(701).\n", __FUNCTION__, pre_state.GetChars());
		return NPT_FAILURE;
	}

	change_transport_state(TRANSPORT_PAUSED_PLAYBACK);

	return NPT_SUCCESS;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnPlay
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnPlay(PLT_ActionReference& action)
{
	NPT_AutoLock lock(m_state);

    if (m_Delegate) {
        return m_Delegate->OnPlay(action);
    }

	PLT_Service *avt;
	FindServiceByType("urn:schemas-upnp-org:service:AVTransport:1", avt);
	NPT_String pre_state;
    avt->GetStateVariableValue("TransportState", pre_state);

	if(!pre_state.Compare("PLAYING"))
	{
		printf("%s: Warn: no change.\n", __FUNCTION__);
		return NPT_SUCCESS;
	}
	else if(!pre_state.Compare("PAUSED_PLAYBACK"))
	{
		// pause->play
		printf("%s: pause->play.\n", __FUNCTION__);
		// resume
		system("echo \"pause\" > /tmp/mplayer-infifo");
	}
	else if(!pre_state.Compare("NO_MEDIA_PRESENT") || !pre_state.Compare("STOPPED"))
	{
		// stop->play
		printf("%s: stop->play.\n", __FUNCTION__);
		// get uri
		NPT_String uri;
		avt->GetStateVariableValue("AVTransportURI", uri);
		if(uri.IsEmpty())
		{
			printf("%s: Error: uri(null).\n", __FUNCTION__);
			return NPT_FAILURE;
		}
		NPT_String meta;
		avt->GetStateVariableValue("AVTransportURIMetaData", meta);
		// update
		last_duration = -1;
		last_position = -1;
		avt->SetStateVariable("RelativeTimePosition", "00:00:00"); 
		avt->SetStateVariable("AbsoluteTimePosition", "00:00:00");
		avt->SetStateVariable("CurrentTrackDuration", "00:00:00");
		avt->SetStateVariable("CurrentMediaDuration", "00:00:00");
		avt->SetStateVariable("CurrentTrackURI", uri);
		avt->SetStateVariable("CurrentTrackMetadata", meta);
		avt->SetStateVariable("CurrentTrack", "1");
		// play
		system("echo -n > /tmp/mplayer-ack");
		char buf[1024];
		snprintf(buf, sizeof(buf), 
			"echo \"loadfile %s\" > /tmp/mplayer-infifo", uri.GetChars());
		printf("cmd=%s\n", buf);
		system(buf);
	}
	else
	{
		printf("%s: Error: %s(701).\n", __FUNCTION__, pre_state.GetChars());
		return NPT_FAILURE;
	}

	change_transport_state(TRANSPORT_PLAYING);

    return NPT_SUCCESS;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnPrevious
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnPrevious(PLT_ActionReference& action)
{
    if (m_Delegate) {
        return m_Delegate->OnPrevious(action);
    }
    return NPT_ERROR_NOT_IMPLEMENTED;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnSeek
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnSeek(PLT_ActionReference& action)
{
	NPT_AutoLock lock(m_state);

    if (m_Delegate) {
        return m_Delegate->OnSeek(action);
    }

	PLT_Service *avt;
	FindServiceByType("urn:schemas-upnp-org:service:AVTransport:1", avt);
	NPT_String pre_state;
    avt->GetStateVariableValue("TransportState", pre_state);

	if(pre_state.Compare("PLAYING"))
	{
		printf("%s: Error: is not playing.\n", __FUNCTION__);
		return NPT_ERROR_INVALID_STATE;
	}

    NPT_String unit, target;
	NPT_CHECK_SEVERE(action->GetArgumentValue("Unit", unit));
	NPT_CHECK_SEVERE(action->GetArgumentValue("Target", target));

	if (unit.Compare("REL_TIME")) {
		printf("%s: Error: is not REL_TIME.\n", __FUNCTION__);
		return NPT_FAILURE;
	}
	printf("%s: Target: %s.\n", __FUNCTION__, target.GetChars());
	
	// converts target
	int position = parse_upnp_time(target.GetChars());
	char buf[64];
	snprintf(buf, sizeof(buf), 
		"echo \"seek %d 2\" > /tmp/mplayer-infifo", position);
	printf("cmd=%s\n", buf);
	system(buf);

	printf("%s: play->transitioning.\n", __FUNCTION__);
	change_transport_state(TRANSPORT_TRANSITIONING);	// qplay
	seek_target = position;

	return NPT_SUCCESS;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnStop
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnStop(PLT_ActionReference& action)
{
	NPT_AutoLock lock(m_state);

    if (m_Delegate) {
        return m_Delegate->OnStop(action);
    }

	PLT_Service *avt;
	FindServiceByType("urn:schemas-upnp-org:service:AVTransport:1", avt);
	NPT_String pre_state;
    avt->GetStateVariableValue("TransportState", pre_state);

	// stop
	printf("%s: %s->stop.\n", __FUNCTION__, pre_state.GetChars());
	system("echo \"stop\" > /tmp/mplayer-infifo");

	last_duration = -1;
	last_position = -1;

	avt->SetStateVariable("RelativeTimePosition", "00:00:00"); 
	avt->SetStateVariable("AbsoluteTimePosition", "00:00:00");
	avt->SetStateVariable("CurrentTrackDuration", "00:00:00");
	avt->SetStateVariable("CurrentMediaDuration", "00:00:00");

	//avt->SetStateVariable("AVTransportURI", "");
	//avt->SetStateVariable("AVTransportURIMetadata", "");
	//avt->SetStateVariable("NumberOfTracks", "0");

	avt->SetStateVariable("CurrentTrackURI", "");
	avt->SetStateVariable("CurrentTrackMetadata", "");
	avt->SetStateVariable("CurrentTrack", "0");

	change_transport_state(TRANSPORT_NO_MEDIA_PRESENT);

	// wait over
	if(!pre_state.Compare("PLAYING") || !pre_state.Compare("TRANSITIONING"))
	{
		int i=15;
		char buf[12];

		while(i--)
		{
			memset(buf, 0, sizeof(buf));
			if(get_ack(buf, sizeof(buf)) == 0)
			{
				if(memcmp(buf, "over", sizeof("over")-1) == 0)
				{
					printf("%s: wait over!\n", __FUNCTION__);
					break;
				}
			}

			usleep(100*1000);
		}
	}

	return NPT_SUCCESS;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnSetAVTransportURI
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnSetAVTransportURI(PLT_ActionReference& action)
{
	NPT_AutoLock lock(m_state);

    if (m_Delegate) {
        return m_Delegate->OnSetAVTransportURI(action);
    }
    
    // default implementation is using state variable
    NPT_String uri;
    NPT_CHECK_WARNING(action->GetArgumentValue("CurrentURI", uri));

    NPT_String metadata;
    NPT_CHECK_WARNING(action->GetArgumentValue("CurrentURIMetaData", metadata));
    
    PLT_Service* serviceAVT;
    NPT_CHECK_WARNING(FindServiceByType("urn:schemas-upnp-org:service:AVTransport:1", serviceAVT));

    // update service state variables
    serviceAVT->SetStateVariable("AVTransportURI", uri);
    serviceAVT->SetStateVariable("AVTransportURIMetaData", metadata);
	serviceAVT->SetStateVariable("NumberOfTracks", "1");

	//printf("%s: CurrentURI: %s.\n", __FUNCTION__, uri.GetChars());
	//printf("%s: CurrentURIMetaData: %s.\n", __FUNCTION__, metadata.GetChars());

    return NPT_SUCCESS;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnSetPlayMode
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnSetPlayMode(PLT_ActionReference& action)
{
    if (m_Delegate) {
        return m_Delegate->OnSetPlayMode(action);
    }
    return NPT_ERROR_NOT_IMPLEMENTED;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnSetVolume
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnSetVolume(PLT_ActionReference& action)
{
	NPT_AutoLock lock(m_state);

    if (m_Delegate) {
        return m_Delegate->OnSetVolume(action);
    }

	NPT_String volume;
	NPT_CHECK_SEVERE(action->GetArgumentValue("DesiredVolume", volume));
	printf("%s: DesiredVolume: %s.\n", __FUNCTION__, volume.GetChars());

	int volume_level = atoi(volume.GetChars());  // range 0..100
	if (volume_level < 0) volume_level = 0;
	if (volume_level > 100) volume_level = 100;

	// kugou 0-15
	PLT_Service *avt;
	FindServiceByType("urn:schemas-upnp-org:service:AVTransport:1", avt);
	NPT_String meta;
	avt->GetStateVariableValue("AVTransportURIMetaData", meta);
	if(meta.Find("kugou.com") >= 0)
	{
		volume_level = volume_level * 20 / 3;

		printf("%s: kugou=%d.\n", __FUNCTION__, volume_level);
	}

	PLT_Service *rct;
	FindServiceByType("urn:schemas-upnp-org:service:RenderingControl:1", rct);
	NPT_String mute;
	rct->GetStateVariableValue("Mute", mute);
	printf("%s: Mute: %s.\n", __FUNCTION__, mute.GetChars());

	int val = volume_level * 4 / 5;
	if( volume_level && (val == 0) )
		val = 1;

	char buf[64];
	snprintf(buf, sizeof(buf), 
		"amixer cset numid=5 %d", 0x2f + val);
	printf("cmd=%s\n", buf);
	system(buf);

	// update volume
	rct->SetStateVariable("Volume", volume);

    return NPT_SUCCESS;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnSetVolumeDB
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnSetVolumeDB(PLT_ActionReference& action)
{
    if (m_Delegate) {
        return m_Delegate->OnSetVolumeDB(action);
    }
    return NPT_ERROR_NOT_IMPLEMENTED;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnGetVolumeDBRange
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnGetVolumeDBRange(PLT_ActionReference& action)
{
    if (m_Delegate) {
        return m_Delegate->OnGetVolumeDBRange(action);
    }
    return NPT_ERROR_NOT_IMPLEMENTED;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::OnSetMute
+---------------------------------------------------------------------*/
NPT_Result
PLT_MediaRenderer::OnSetMute(PLT_ActionReference& action)
{
	NPT_AutoLock lock(m_state);

    if (m_Delegate) {
        return m_Delegate->OnSetMute(action);
    }

 	NPT_String mute;
	NPT_CHECK_SEVERE(action->GetArgumentValue("DesiredMute", mute));
	printf("%s: DesiredMute: %s.\n", __FUNCTION__, mute.GetChars());
	
	if(!mute.Compare("1"))
	{
		// mute
		system("amixer cset numid=37 off");
		system("amixer cset numid=40 off");

		printf("%s: mute!!!\n", __FUNCTION__);
	}
	else
	{
		// unmute
		system("amixer cset numid=37 on");
		system("amixer cset numid=40 on");

		printf("%s: unmute!!!\n", __FUNCTION__);
	}

	PLT_Service *rct;
	FindServiceByType("urn:schemas-upnp-org:service:RenderingControl:1", rct);
	rct->SetStateVariable("Mute", mute);
	
	return NPT_SUCCESS;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::get_position
+---------------------------------------------------------------------*/
void
PLT_MediaRenderer::get_position()
{
	NPT_AutoLock lock(m_state);

	PLT_Service *avt;
	FindServiceByType("urn:schemas-upnp-org:service:AVTransport:1", avt);
	NPT_String pre_state;
    avt->GetStateVariableValue("TransportState", pre_state);

	if( (pre_state.Compare("PLAYING") != 0) && 
		(pre_state.Compare("TRANSITIONING") != 0) )
		return;

	//printf("%s.\n", __FUNCTION__);

	char buf[12];
	int position;
	char tbuf[32];

	memset(buf, 0, sizeof(buf));
	if(get_ack(buf, sizeof(buf)))
		return;

	if(memcmp(buf, "over", sizeof("over")-1) == 0)
	{
		// seek error
		if(!pre_state.Compare("TRANSITIONING"))
		{
			printf("%s: seek error, transitioning->play.\n", __FUNCTION__);
			change_transport_state(TRANSPORT_PLAYING);
			return;
		}

		// last_position = last_duration = -1 
		// kugou wma, mplayer fail
		;

		if(last_position < last_duration)
		{
			last_position += 1;

			print_upnp_time(tbuf, sizeof(tbuf), last_position);
			avt->SetStateVariable("RelativeTimePosition", tbuf);
    		avt->SetStateVariable("AbsoluteTimePosition", tbuf);
			printf("%s: last_position:%s.\n", __FUNCTION__, tbuf);
			return;
		}

		// over
		printf("%s: over.\n", __FUNCTION__);
		system("echo -n > /tmp/mplayer-ack");
		change_transport_state(TRANSPORT_STOPPED);
	}
	else
	{
		if(last_duration == -1)
		{
			system("echo \"get_time_length\" > /tmp/mplayer-infifo");
			memset(buf, 0, sizeof(buf));
			if(get_ack(buf, sizeof(buf)))
				return;

			if(memcmp(buf, "len=", sizeof("len=")-1) != 0)
				return;

			last_duration = atoi(buf+sizeof("len=")-1);
			print_upnp_time(tbuf, sizeof(tbuf), last_duration);
			avt->SetStateVariable("CurrentTrackDuration", tbuf);
    		avt->SetStateVariable("CurrentMediaDuration", tbuf);
			printf("%s: last_duration:%s.\n", __FUNCTION__, tbuf);
		}

		system("echo \"get_time_pos\" > /tmp/mplayer-infifo");
		memset(buf, 0, sizeof(buf));
		if(get_ack(buf, sizeof(buf)))
			return;

		if(memcmp(buf, "pos=", sizeof("pos=")-1) != 0)
			return;

		position = atoi(buf+sizeof("pos=")-1);
		if (position != last_position) {
			if(position > last_duration)
			{
				printf("%s: Error: position(%d)>last_duration(%d)!\n", __FUNCTION__, position, last_duration);
				return;
			}
			print_upnp_time(tbuf, sizeof(tbuf), position);
			avt->SetStateVariable("RelativeTimePosition", tbuf);
    		avt->SetStateVariable("AbsoluteTimePosition", tbuf);
			//printf("%s: position:%s.\n", __FUNCTION__, tbuf);
			last_position = position;

			if(!pre_state.Compare("TRANSITIONING"))
			{
				if(position >= seek_target)
				{
					printf("%s: transitioning->play.\n", __FUNCTION__);
					change_transport_state(TRANSPORT_PLAYING);
				}
			}
		}
	}
}

#define OUTPUT "/tmp/mplayer-ack"
/*----------------------------------------------------------------------
|   PLT_MediaRenderer::get_ack
+---------------------------------------------------------------------*/
int
PLT_MediaRenderer::get_ack(char *data, int size)
{
	FILE *fp = NULL;

	fp = fopen(OUTPUT, "r");
	if(fp)
	{
		fread(data, size, 1, fp);
		fclose(fp);
		return 0;
	}

	printf("%s: open %s error.\n", __FUNCTION__, OUTPUT);
	return -1;
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::change_transport_state
+---------------------------------------------------------------------*/
void
PLT_MediaRenderer::change_transport_state(enum transport_state new_state)
{
	PLT_Service *avt;
	FindServiceByType("urn:schemas-upnp-org:service:AVTransport:1", avt);

	const char *transport_states = NULL;
	const char *available_actions = NULL;
	switch (new_state) {
	case TRANSPORT_STOPPED:
		transport_states = "STOPPED";
		available_actions = "PLAY";
		break;
	case TRANSPORT_PLAYING:
		transport_states = "PLAYING";
		available_actions = "PAUSE,STOP,SEEK,X_DLNA_SeekTime";
		break;
	case TRANSPORT_PAUSED_PLAYBACK:
		transport_states = "PAUSED_PLAYBACK";
		available_actions = "PLAY,STOP";
		break;
	case TRANSPORT_TRANSITIONING:
		transport_states = "TRANSITIONING";
		break;
	case TRANSPORT_PAUSED_RECORDING:
		transport_states = "PAUSED_RECORDING";
		break;
	case TRANSPORT_RECORDING:
		transport_states = "RECORDING";
		break;
	case TRANSPORT_NO_MEDIA_PRESENT:
		transport_states = "NO_MEDIA_PRESENT";
		available_actions = "PLAY";
		break;
	}

	avt->SetStateVariable("TransportState", transport_states);
	
	if (available_actions) {
		avt->SetStateVariable("CurrentTransportActions", available_actions);
	}
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::print_upnp_time
+---------------------------------------------------------------------*/
void
PLT_MediaRenderer::print_upnp_time(char *result, int size, int t)
{
	const int hour = t / (60*60);
	const int minute = (t % (60*60)) / 60;
	const int second = (t % (60*60)) % 60;
	snprintf(result, size, "%02d:%02d:%02d", hour, minute, second);
}

/*----------------------------------------------------------------------
|   PLT_MediaRenderer::parse_upnp_time
+---------------------------------------------------------------------*/
int
PLT_MediaRenderer::parse_upnp_time(const char *time_string)
{
	int hour = 0;
	int minute = 0;
	int second = 0;
	sscanf(time_string, "%d:%02d:%02d", &hour, &minute, &second);
	const int seconds = (hour * 3600 + minute * 60 + second);
	return seconds;
}

/*
baidu/kugou/qq/bubbleupnp/win7 ok
xmly can't next
ape: stop fail

normal: stop->uri->play->over->stop->uri->play
baidu: uri->play->over
xmly: stop->uri->play->over

xmly: stop->uri->stop->play x
*/
