SOURCE_FOLDER=bluez-5.39
SOURCES="\
	 $SOURCE_FOLDER/tools/btgatt-client.c \
	 $SOURCE_FOLDER/src/shared/mainloop.c \
	 $SOURCE_FOLDER/src/shared/gatt-db.c \
	 $SOURCE_FOLDER/lib/uuid.c \
	 $SOURCE_FOLDER/src/shared/util.c \
	 $SOURCE_FOLDER/src/shared/att.c \
	 $SOURCE_FOLDER/src/shared/gatt-client.c \
	 $SOURCE_FOLDER/lib/bluetooth.c \
	 $SOURCE_FOLDER/lib/hci.c \
	 $SOURCE_FOLDER/src/shared/timeout-mainloop.c \
	 $SOURCE_FOLDER/src/shared/queue.c \
	 $SOURCE_FOLDER/src/shared/crypto.c \
	 $SOURCE_FOLDER/src/shared/io-mainloop.c \
	 $SOURCE_FOLDER/src/shared/gatt-helpers.c \
	 "
CFLAGS=-I$SOURCE_FOLDER
CC=gcc

$CC $SOURCES $CFLAGS -o ./btgatt-cli
