SOURCE_FOLDER=bluez-5.39
SOURCES="\
	 le-init.c \
	 btgatt-server-demo.c \
	 $SOURCE_FOLDER/src/shared/mainloop.c \
	 $SOURCE_FOLDER/src/shared/gatt-db.c \
	 $SOURCE_FOLDER/src/shared/gatt-server.c \
	 $SOURCE_FOLDER/src/shared/timeout-mainloop.c \
	 $SOURCE_FOLDER/lib/uuid.c \
	 $SOURCE_FOLDER/src/shared/util.c \
	 $SOURCE_FOLDER/src/shared/att.c \
	 $SOURCE_FOLDER/lib/bluetooth.c \
	 $SOURCE_FOLDER/lib/hci.c \
	 $SOURCE_FOLDER/src/shared/queue.c \
	 $SOURCE_FOLDER/src/shared/crypto.c \
	 $SOURCE_FOLDER/src/shared/io-mainloop.c \
	 "
CFLAGS=-I$SOURCE_FOLDER
CC=gcc

$CC $SOURCES $CFLAGS -Wall -o ./gatt-srv-demo
