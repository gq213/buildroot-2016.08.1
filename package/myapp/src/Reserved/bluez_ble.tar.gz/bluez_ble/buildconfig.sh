SOURCE_FOLDER=bluez-5.39
SOURCES="\
	 hciconfig.c \
	 $SOURCE_FOLDER/lib/hci.c \
	 $SOURCE_FOLDER/lib/bluetooth.c \
	 $SOURCE_FOLDER/tools/csr.c \
	 "
CFLAGS=-I$SOURCE_FOLDER
CC=gcc

$CC $SOURCES $CFLAGS -o ./hciconfig
